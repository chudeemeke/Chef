import React, { useState } from 'react';
import { db } from '../db';
import type { User } from '../types';
import { DIETARY_OPTIONS } from '../constants';
import { TrashIcon, CheckIcon, MoonIcon, SunIcon } from './icons';

interface ProfileViewProps {
  user: User;
  onUpdateUser: (updates: Partial<User>) => void;
  onLogout: () => void;
  showToast: (msg: string) => void;
}

const ProfileView: React.FC<ProfileViewProps> = ({ user, onUpdateUser, onLogout, showToast }) => {
  const [name, setName] = useState(user.name);
  const [isEditing, setIsEditing] = useState(false);

  const handleSaveName = () => {
      if (name.trim()) {
          onUpdateUser({ name: name.trim() });
          setIsEditing(false);
          showToast('Name updated');
      }
  };

  const toggleDietaryFilter = (filter: string) => {
      const current = user.preferences.dietaryFilters || [];
      const updated = current.includes(filter)
          ? current.filter(f => f !== filter)
          : [...current, filter];
      
      onUpdateUser({ 
          preferences: { 
              ...user.preferences, 
              dietaryFilters: updated 
          } 
      });
  };

  const toggleDarkMode = () => {
       onUpdateUser({ 
          preferences: { 
              ...user.preferences, 
              darkMode: !user.preferences.darkMode 
          } 
      });
  };

  const handleClearData = async () => {
      if (window.confirm("Are you sure you want to delete ALL your recipes and shopping lists? This cannot be undone.")) {
          await db.shoppingList.where('userId').equals(user.id!).delete();
          await db.recipes.where('userId').equals(user.id!).delete();
          showToast('All your data has been cleared.');
      }
  };

  const handleDeleteProfile = async () => {
      if (window.confirm("Delete this profile completely?")) {
           await db.users.delete(user.id!);
           await db.shoppingList.where('userId').equals(user.id!).delete();
           await db.recipes.where('userId').equals(user.id!).delete();
           onLogout();
      }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-8">
        {/* Profile Header */}
        <div className="flex flex-col items-center text-center">
            <div className="text-6xl mb-4 bg-gray-100 dark:bg-gray-700 rounded-full p-4 w-24 h-24 flex items-center justify-center">
                {user.avatar}
            </div>
            
            {isEditing ? (
                <div className="flex gap-2 items-center mb-2">
                    <input 
                        type="text" 
                        value={name} 
                        onChange={(e) => setName(e.target.value)}
                        className="text-2xl font-bold text-center bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded px-2 py-1 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                    <button onClick={handleSaveName} className="p-2 text-green-600 hover:bg-green-100 rounded-full"><CheckIcon className="w-6 h-6"/></button>
                </div>
            ) : (
                <h2 
                    className="text-3xl font-bold text-gray-900 dark:text-white mb-1 cursor-pointer hover:opacity-70 flex items-center gap-2"
                    onClick={() => setIsEditing(true)}
                    title="Click to edit name"
                >
                    {user.name}
                    <span className="text-sm font-normal text-gray-400">✎</span>
                </h2>
            )}
            <p className="text-gray-500 dark:text-gray-400">Member since {new Date(user.createdAt).toLocaleDateString()}</p>
        </div>

        {/* Settings Card */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Preferences</h3>
            </div>
            
            <div className="p-6 space-y-6">
                {/* Dark Mode */}
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${user.preferences.darkMode ? 'bg-indigo-100 text-indigo-600' : 'bg-yellow-100 text-yellow-600'}`}>
                            {user.preferences.darkMode ? <MoonIcon className="w-5 h-5"/> : <SunIcon className="w-5 h-5"/>}
                        </div>
                        <div>
                            <p className="font-medium text-gray-900 dark:text-white">Appearance</p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{user.preferences.darkMode ? 'Dark Mode' : 'Light Mode'}</p>
                        </div>
                    </div>
                    <button 
                        onClick={toggleDarkMode}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 ${user.preferences.darkMode ? 'bg-blue-600' : 'bg-gray-200'}`}
                    >
                        <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${user.preferences.darkMode ? 'translate-x-6' : 'translate-x-1'}`} />
                    </button>
                </div>

                {/* Dietary Filters */}
                <div>
                    <p className="font-medium text-gray-900 dark:text-white mb-3">Default Dietary Preferences</p>
                    <div className="flex flex-wrap gap-2">
                        {DIETARY_OPTIONS.map(option => {
                            const isActive = user.preferences.dietaryFilters.includes(option);
                            return (
                                <button
                                    key={option}
                                    onClick={() => toggleDietaryFilter(option)}
                                    className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
                                        isActive 
                                            ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300 ring-2 ring-blue-500 dark:ring-blue-400' 
                                            : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                                    }`}
                                >
                                    {option}
                                </button>
                            );
                        })}
                    </div>
                </div>
            </div>
        </div>

        {/* Danger Zone */}
        <div className="bg-red-50 dark:bg-red-900/10 rounded-2xl border border-red-200 dark:border-red-900/30 overflow-hidden">
            <div className="p-6">
                <h3 className="text-lg font-semibold text-red-800 dark:text-red-400 mb-4">Danger Zone</h3>
                <div className="space-y-3">
                     <button 
                        onClick={handleClearData}
                        className="w-full text-left px-4 py-3 bg-white dark:bg-gray-800 border border-red-200 dark:border-red-800/30 rounded-lg text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors flex items-center justify-between group"
                    >
                        <span>Clear Saved Data (Recipes & Shopping List)</span>
                        <TrashIcon className="w-5 h-5 opacity-60 group-hover:opacity-100" />
                    </button>
                    <button 
                        onClick={onLogout}
                        className="w-full text-left px-4 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                    >
                        Log Out
                    </button>
                    <button 
                        onClick={handleDeleteProfile}
                        className="w-full text-left px-4 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium"
                    >
                        Delete Profile Permanently
                    </button>
                </div>
            </div>
        </div>
    </div>
  );
};

export default ProfileView;