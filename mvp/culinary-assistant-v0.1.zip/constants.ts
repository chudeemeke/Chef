
export const DIETARY_OPTIONS = [
  'Vegetarian',
  'Keto',
  'Gluten-Free',
  'Vegan',
  'Low-Carb'
];
