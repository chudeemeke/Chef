import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from './db';
import { getRecipesFromImage, generateRecipeImage, generateRecipesFromIngredients } from './services/geminiService';
import type { Recipe, ShoppingListItem, Ingredient, User } from './types';
import { DIETARY_OPTIONS } from './constants';
import ImageUpload from './components/ImageUpload';
import RecipeList from './components/RecipeList';
import CookingModeView from './components/CookingModeView';
import ShoppingListView from './components/ShoppingListView';
import FavoritesView from './components/FavoritesView';
import FilterSidebar from './components/FilterSidebar';
import Header, { ActiveTab } from './components/Header';
import Spinner from './components/Spinner';
import Toast from './components/Toast';
import LoginView from './components/LoginView';
import ProfileView from './components/ProfileView';

const App: React.FC = () => {
  // --- User State ---
  const [userId, setUserId] = useState<number | null>(() => {
      const stored = localStorage.getItem('currentUserId');
      return stored ? Number(stored) : null;
  });

  // Query user data directly from DB
  const currentUser = useLiveQuery(() => userId ? db.users.get(userId) : undefined, [userId]);
  
  // --- Data Queries using Dexie Live Query ---
  const shoppingList = useLiveQuery(
      () => userId ? db.shoppingList.where('userId').equals(userId).toArray() : [], 
      [userId]
  ) || [];

  const favorites = useLiveQuery(
      () => userId ? db.recipes.where('[userId+isFavorite]').equals([userId, 1]).toArray() : [],
      [userId]
  ) || [];

  // --- UI State ---
  const [image, setImage] = useState<string | null>(null);
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [filteredRecipes, setFilteredRecipes] = useState<Recipe[]>([]);
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [activeTab, setActiveTab] = useState<ActiveTab>('recipes');
  
  // Filters
  const [activeFilters, setActiveFilters] = useState<string[]>([]);
  const [activeDifficultyFilters, setActiveDifficultyFilters] = useState<string[]>([]);
  
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('Analyzing your fridge...');
  const [error, setError] = useState<string | null>(null);

  // Global Toast State
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error'; visible: boolean }>({
      message: '',
      type: 'success',
      visible: false
  });

  const showToast = useCallback((message: string, type: 'success' | 'error' = 'success') => {
      setToast({ message, type, visible: true });
  }, []);

  const hideToast = useCallback(() => {
      setToast(prev => ({ ...prev, visible: false }));
  }, []);

  // --- Effects ---

  // Handle Theme and Default Filters based on User Preferences
  useEffect(() => {
    if (currentUser) {
        const root = window.document.documentElement;
        if (currentUser.preferences.darkMode) {
            root.classList.add('dark');
        } else {
            root.classList.remove('dark');
        }
        
        // Only set default filters if we haven't manually changed them in this session yet
        if (activeFilters.length === 0 && currentUser.preferences.dietaryFilters.length > 0) {
            setActiveFilters(currentUser.preferences.dietaryFilters);
        }

        // Set default difficulty filters
        if (activeDifficultyFilters.length === 0 && currentUser.preferences.difficultyFilters && currentUser.preferences.difficultyFilters.length > 0) {
            setActiveDifficultyFilters(currentUser.preferences.difficultyFilters);
        }
    }
  }, [currentUser]); 

  // Filter Logic
  useEffect(() => {
    let filtered = recipes;

    // Dietary
    if (activeFilters.length > 0) {
      filtered = filtered.filter(recipe =>
        activeFilters.every(filter => recipe.dietaryTags.includes(filter))
      );
    }
    
    // Difficulty
    if (activeDifficultyFilters.length > 0) {
      filtered = filtered.filter(recipe =>
        activeDifficultyFilters.includes(recipe.difficulty)
      );
    }

    setFilteredRecipes(filtered);
  }, [recipes, activeFilters, activeDifficultyFilters]);

  // --- Handlers ---

  const handleLogin = (user: User) => {
      if (user.id) {
          setUserId(user.id);
          localStorage.setItem('currentUserId', String(user.id));
      }
  };

  const handleLogout = () => {
      setUserId(null);
      localStorage.removeItem('currentUserId');
      setRecipes([]);
      setActiveTab('recipes');
      setImage(null);
  };

  const handleUpdateUser = async (updates: Partial<User>) => {
      if (userId) {
          await db.users.update(userId, updates);
      }
  };

  const processRecipes = async (fetchedRecipes: Recipe[]) => {
      const recipesWithImages = await Promise.all(
        fetchedRecipes.map(async (recipe) => {
          const imageUrls = await generateRecipeImage(recipe.name, recipe.description);
          return { ...recipe, imageUrls, userId: userId || undefined };
        })
      );
      setRecipes(recipesWithImages);
  };

  const handleImageAnalysis = useCallback(async (base64Image: string) => {
    setImage(base64Image);
    setIsLoading(true);
    setLoadingMessage("Analyzing your fridge...");
    setError(null);
    setRecipes([]);
    setSelectedRecipe(null);
    try {
      const generatedRecipes = await getRecipesFromImage(base64Image);
      await processRecipes(generatedRecipes);
    } catch (err: any) {
      const msg = err.message || 'Failed to get recipes.';
      setError(msg);
      showToast(msg, 'error');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [showToast, userId]);

  const handleGenerateRecipeFromShoppingList = useCallback(async (ingredients: string[]) => {
      setIsLoading(true);
      setLoadingMessage("Creating recipes from your shopping list...");
      setError(null);
      setSelectedRecipe(null);
      
      setActiveTab('recipes');
      
      try {
          const generatedRecipes = await generateRecipesFromIngredients(ingredients);
          await processRecipes(generatedRecipes);
      } catch (err: any) {
          const msg = err.message || 'Failed to create recipes.';
          setError(msg);
          showToast(msg, 'error');
          console.error(err);
      } finally {
          setIsLoading(false);
      }
  }, [showToast, userId]);

  const handleFilterChange = (filter: string, isChecked: boolean) => {
    setActiveFilters(prev =>
      isChecked ? [...prev, filter] : prev.filter(f => f !== filter)
    );
  };

  const handleDifficultyFilterChange = (filter: string, isChecked: boolean) => {
    setActiveDifficultyFilters(prev => 
      isChecked ? [...prev, filter] : prev.filter(f => f !== filter)
    );
  };
  
  // DB Operations for Shopping List
  const handleAddToShoppingList = useCallback(async (itemText: string, category: string, ingredient?: Ingredient) => {
    if (!userId) return;
    
    // Check duplicates in DB
    const exists = await db.shoppingList.where({ userId: userId, text: itemText }).first();
    
    if (!exists) {
        await db.shoppingList.add({
            userId,
            text: itemText,
            category: category || 'Other',
            checked: false,
            ingredient
        });
        showToast(`Added ${itemText} to list`, 'success');
    } else {
        showToast(`${itemText} is already in your list`, 'success');
    }
  }, [showToast, userId]);

  const handleUpdateShoppingItem = async (id: string, updates: Partial<ShoppingListItem>) => {
      await db.shoppingList.update(Number(id), updates);
  };

  const handleToggleShoppingItem = async (itemId: string) => {
      const item = await db.shoppingList.get(Number(itemId));
      if (item) {
          await db.shoppingList.update(Number(itemId), { checked: !item.checked });
      }
  };
  
  const handleReorderShoppingList = (items: ShoppingListItem[]) => {
      // Logic placeholder for persisting reorder if needed
  };

  const handleClearShoppingList = async () => {
      if (userId && window.confirm("Delete all shopping items?")) {
          await db.shoppingList.where('userId').equals(userId).delete();
      }
  }

  const handleUncheckAllShoppingList = async () => {
      if (userId && window.confirm("Restart list?")) {
          await db.shoppingList.where('userId').equals(userId).modify({ checked: false });
      }
  }

  // DB Operations for Favorites
  const handleToggleFavorite = useCallback(async (recipe: Recipe) => {
    if (!userId) return;

    // Check if recipe exists in DB as favorite
    const existing = await db.recipes.where({ userId: userId, name: recipe.name, isFavorite: 1 }).first();

    if (existing) {
        await db.recipes.delete(existing.id!);
        showToast('Removed from favorites');
    } else {
        await db.recipes.add({
            ...recipe,
            userId,
            isFavorite: true,
            createdAt: Date.now()
        });
        showToast('Added to favorites');
    }
  }, [showToast, userId]);

  const handleReset = () => {
    setImage(null);
    setRecipes([]);
    setSelectedRecipe(null);
    setError(null);
    setIsLoading(false);
    setActiveTab('recipes');
  };

  // --- Render ---

  // If userId is present but currentUser is not yet loaded, show loading to avoid Login flash
  if (userId && currentUser === undefined) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 dark:bg-gray-900">
            <Spinner />
        </div>
      );
  }

  if (!userId || !currentUser) {
      return <LoginView onLogin={handleLogin} />;
  }

  const renderActiveView = () => {
    switch (activeTab) {
        case 'shoppingList':
            const uiShoppingList = shoppingList.map(i => ({...i, id: String(i.id)}));
            return <ShoppingListView 
                      items={uiShoppingList}
                      onAddItem={handleAddToShoppingList}
                      onUpdateItem={handleUpdateShoppingItem}
                      onToggleItem={handleToggleShoppingItem}
                      onClear={handleClearShoppingList}
                      onUncheckAll={handleUncheckAllShoppingList}
                      onGenerateRecipe={handleGenerateRecipeFromShoppingList}
                      onReorderItems={handleReorderShoppingList}
                   />;
        case 'favorites':
            return <FavoritesView 
                        favorites={favorites} 
                        onSelectRecipe={setSelectedRecipe}
                        onToggleFavorite={handleToggleFavorite}
                    />;
        case 'profile':
            return <ProfileView 
                        user={currentUser}
                        stats={{
                          favoritesCount: favorites.length,
                          shoppingListCount: shoppingList.length
                        }}
                        onNavigate={setActiveTab}
                        onUpdateUser={handleUpdateUser}
                        onLogout={handleLogout}
                        showToast={showToast}
                   />;
        case 'recipes':
        default:
            return currentRecipeView;
    }
  }

  const currentRecipeView = (
    <>
    {selectedRecipe ? (
        <CookingModeView
          recipe={selectedRecipe}
          onExit={() => setSelectedRecipe(null)}
          onAddToShoppingList={handleAddToShoppingList}
          onShowToast={showToast}
        />
    ) : isLoading ? (
        <div className="flex flex-col items-center justify-center h-full text-center p-8 dark:text-gray-200">
          <Spinner />
          <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100 mt-4">{loadingMessage}</h2>
          <p className="text-gray-600 dark:text-gray-400 mt-2">Our AI chef is working their magic...</p>
        </div>
    ) : error ? (
        <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <p className="text-red-500 text-lg dark:text-red-400 font-medium mb-4">{error}</p>
            <button onClick={handleReset} className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition shadow-md">Try Again</button>
        </div>
    ) : recipes.length > 0 ? (
       <RecipeList 
                recipes={filteredRecipes} 
                onSelectRecipe={setSelectedRecipe} 
                onReset={handleReset}
                favorites={favorites}
                onToggleFavorite={handleToggleFavorite}
       />
    ) : (
       <ImageUpload onImageUpload={handleImageAnalysis} />
    )}
    </>
  );

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
      <Header 
        user={currentUser}
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        onReset={handleReset} 
        toggleDarkMode={() => handleUpdateUser({ preferences: { ...currentUser.preferences, darkMode: !currentUser.preferences.darkMode }})}
        onLogout={handleLogout}
      />
      <div className="flex-grow flex flex-col md:flex-row container mx-auto p-4 md:p-6 gap-6">
        {activeTab === 'recipes' && recipes.length > 0 && !selectedRecipe && (
          <FilterSidebar
            dietaryOptions={DIETARY_OPTIONS}
            activeDietaryFilters={activeFilters}
            onDietaryChange={handleFilterChange}
            difficultyOptions={['Easy', 'Medium', 'Hard']}
            activeDifficultyFilters={activeDifficultyFilters}
            onDifficultyChange={handleDifficultyFilterChange}
          />
        )}
        <main className="flex-grow bg-white dark:bg-gray-800 rounded-2xl shadow-lg dark:shadow-gray-900/50 dark:border dark:border-gray-700 overflow-hidden flex flex-col transition-colors duration-200">
            {renderActiveView()}
        </main>
      </div>
      <Toast message={toast.message} type={toast.type} isVisible={toast.visible} onClose={hideToast} />
    </div>
  );
};

export default App;