import React from 'react';
import type { Recipe } from '../types';
import RecipeCard from './RecipeCard';
import { PlusIcon } from './icons';

interface RecipeListProps {
  recipes: Recipe[];
  favorites: Recipe[];
  onSelectRecipe: (recipe: Recipe) => void;
  onToggleFavorite: (recipe: Recipe) => void;
  onReset: () => void;
}

const RecipeList: React.FC<RecipeListProps> = ({ recipes, favorites, onSelectRecipe, onToggleFavorite, onReset }) => {
  if (recipes.length === 0) {
    return (
        <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <h2 className="text-2xl font-semibold text-gray-700 dark:text-gray-200">No Recipes Found</h2>
            <p className="text-gray-500 dark:text-gray-400 mt-2">Try adjusting your filters or uploading a new photo.</p>
            <button onClick={onReset} className="mt-6 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">Start Over</button>
        </div>
    )
  }
  
  const isFavorite = (recipe: Recipe) => favorites.some(fav => fav.name === recipe.name);

  return (
    <div className="p-4 sm:p-6 h-full flex flex-col relative">
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Your Recipe Suggestions</h2>
        </div>
      
        <div className="flex-grow overflow-y-auto pr-2 custom-scrollbar">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recipes.map((recipe, index) => (
                <RecipeCard 
                    key={`${recipe.name}-${index}`} 
                    recipe={recipe} 
                    onSelect={() => onSelectRecipe(recipe)}
                    onToggleFavorite={() => onToggleFavorite(recipe)}
                    isFavorite={isFavorite(recipe)}
                />
            ))}
            </div>
        </div>

        <button
          onClick={onReset}
          className="absolute bottom-6 right-6 bg-blue-600 text-white p-4 rounded-full shadow-lg hover:bg-blue-700 transition-transform transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 z-10"
          aria-label="Upload a new photo"
        >
          <PlusIcon className="w-8 h-8" />
        </button>
    </div>
  );
};

export default RecipeList;